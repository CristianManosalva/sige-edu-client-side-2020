import React from 'react';
import {

    Row, Col,
} from 'reactstrap';

import {
    
} from 'components';

class UITest extends React.Component{
   
    
    render(){

        return (
            <div>
                <div className="content">
                    <Row>
                        <Col xs={12} md={12}>

                    <div className="page-title">
                        <div className="float-left">
                            <h1 className="title">Timeline Centered</h1>
                        </div>
                    </div>


                            
           
                                
                        </Col>

                    </Row>
                </div>
            </div>
        );
    }
}

export default UITest;
