# Change Log

## [1.1.0] 2020-01-25
### Updated Bootstrap, Reactjs, jQuery and node-sass versions.

## [1.0.0] 2018-08-10
### Original Release
